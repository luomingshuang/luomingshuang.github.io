from pathlib import Path
import os,sys,json
assert os.environ.get('CUDA_VISIBLE_DEVICES')not in['0','2']
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import numpy as np,torch,smplx
from scipy.spatial.transform import Rotation
from scipy.signal import savgol_filter
from smplx.lbs import lbs
from ik_pose import swing,unit
D=Path(sys.argv[1]);O=D/'mesh_ground';O.mkdir(exist_ok=True);z=np.load(D/'mesh_anatomical/continuous.npz');rot=z['rotations'].copy();src=np.load(D/'continuous.npz')['joints'];T=len(rot);root=savgol_filter(src[:,0],7,2,axis=0,mode='interp');torch.set_num_threads(1)
m=smplx.SMPLH('/efs/luomingshuang/codes/ActionPlan-Code/deps/smplh/SMPLH_NEUTRAL.npz',ext='npz',gender='neutral',use_pca=False,flat_hand_mean=True,batch_size=64).cuda().eval().requires_grad_(False);parents=m.parents.cpu().numpy().astype(int);weights=m.lbs_weights.cpu().numpy();foot_masks=[weights[:,[7,10]].sum(1)>.2,weights[:,[8,11]].sum(1)>.2]
def skin():
 vs=[];js=[]
 with torch.no_grad():
  for a in range(0,T,64):
   n=min(64,T-a);pose=torch.cat([torch.tensor(rot[a:a+n],device='cuda'),torch.eye(3,device='cuda').reshape(1,1,3,3).expand(n,30,3,3)],1);v,j=lbs(torch.zeros(n,10,device='cuda'),pose,m.v_template,m.shapedirs,m.posedirs,m.J_regressor,m.parents,m.lbs_weights,pose2rot=False);shift=torch.tensor(root[a:a+n,None],device='cuda')-j[:,:1];vs.append((v+shift).cpu().numpy());js.append((j[:,:22]+shift).cpu().numpy())
 return np.concatenate(vs),np.concatenate(js)
v,j=skin()
for iteration in range(3):
 G=np.empty_like(rot)
 for q in range(22):G[:,q]=rot[:,q]if q==0 else G[:,parents[q]]@rot[:,q]
 changes=0
 for leg,(hip,knee,ankle,mask)in enumerate([(1,4,7,foot_masks[0]),(2,5,8,foot_masks[1])]):
  lo=v[:,mask,1].min(1);lift=np.maximum(0,.006-lo)
  for t in np.where(lift>.001)[0]:
   H,K,A=j[t,[hip,knee,ankle]];goal=A+np.array([0,lift[t],0]);L1=np.linalg.norm(K-H);L2=np.linalg.norm(A-K);vv=unit(goal-H);dist=np.clip(np.linalg.norm(goal-H),abs(L1-L2)+1e-5,L1+L2-1e-5);goal=H+dist*vv;pole=K-H-vv*np.dot(K-H,vv)
   if np.linalg.norm(pole)<1e-5:pole=np.cross(vv,G[t,hip,:,0])
   pole=unit(pole);co=np.clip((L1*L1+dist*dist-L2*L2)/(2*L1*dist),-1,1);newK=H+vv*L1*co+pole*L1*np.sqrt(1-co*co);sh=swing(K-H,newK-H);newH=sh@G[t,hip];newQ=swing(sh@(A-K),goal-newK)@sh@G[t,knee];rot[t,hip]=G[t,parents[hip]].T@newH;rot[t,knee]=newH.T@newQ;foot=newQ.T@G[t,ankle];a=Rotation.from_matrix(foot).as_rotvec();a=np.clip(a,[-.9,-.35,-.45],[.9,.35,.45]);a*=min(1,1.05/max(np.linalg.norm(a),1e-9));rot[t,ankle]=Rotation.from_rotvec(a).as_matrix();changes+=1
 v,j=skin()
lo=v[:,:,1].min(1);residual=np.maximum(0,.002-lo);v[:,:,1]+=residual[:,None];j[:,:,1]+=residual[:,None]
np.savez_compressed(O/'continuous.npz',vertices=v,faces=m.faces,joints=j,rotations=rot,root_clearance=residual)
meta=json.load(open(D/'mesh_anatomical/continuous.json'));meta.update(no_contact_repair=False,display_only_contact_ik=True,source_contacts_unchanged=True,contact_ik='Three two-bone IK ground-clearance passes; pelvis preserved; bounded ankles; no vertex warping',max_residual_root_clearance_m=float(residual.max()),mean_joint_fit_error_m=float(np.linalg.norm(j-src,axis=-1).mean()),p95_joint_fit_error_m=float(np.percentile(np.linalg.norm(j-src,axis=-1),95)),max_joint_fit_error_m=float(np.linalg.norm(j-src,axis=-1).max()),rendered_minimum_y=float(v[:,:,1].min()))
(O/'continuous.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta))
