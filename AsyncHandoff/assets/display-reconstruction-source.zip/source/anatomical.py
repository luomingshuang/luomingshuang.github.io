from pathlib import Path
import os,sys,json
assert os.environ.get('CUDA_VISIBLE_DEVICES') not in ['0','2'],'GPU 0/2 reserved by user'
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import numpy as np,torch,smplx
from smplx.lbs import lbs
from scipy.spatial.transform import Rotation
from scipy.signal import savgol_filter
D=Path(sys.argv[1]).resolve();O=D/'mesh_anatomical';O.mkdir(exist_ok=True);z=np.load(D/'mesh_ik/continuous.npz');src=np.load(D/'continuous.npz')['joints'];rot=z['rotations'].copy();T=len(rot);torch.set_num_threads(1)
limits={12:([-.75,-.35,-.50],[.75,.35,.50]),7:([-.9,-.35,-.45],[.9,.35,.45]),8:([-.9,-.35,-.45],[.9,.35,.45]),4:([0,-.08,-.08],[2.65,.08,.08]),5:([0,-.08,-.08],[2.65,.08,.08]),18:([-.10,-2.65,-.10],[.10,0,.10]),19:([-.10,0,-.10],[.10,2.65,.10]),1:([-2.0,-1.0,-1.1],[2.0,1.0,1.1]),2:([-2.0,-1.0,-1.1],[2.0,1.0,1.1])}
for q,(lo,hi)in limits.items():
 a=Rotation.from_matrix(rot[:,q]).as_rotvec();a=np.clip(a,lo,hi)
 if q in[7,8,12]:
  cap=.85 if q==12 else 1.05;a*=np.minimum(1,cap/np.maximum(np.linalg.norm(a,axis=-1),1e-9))[:,None]
 a=savgol_filter(a,5,2,axis=0,mode='interp');a=np.clip(a,lo,hi)
 if q in[7,8,12]:a*=np.minimum(1,(.85 if q==12 else 1.05)/np.maximum(np.linalg.norm(a,axis=-1),1e-9))[:,None]
 rot[:,q]=Rotation.from_rotvec(a).as_matrix()
for q in[10,11,15,20,21]:rot[:,q]=np.eye(3)
m=smplx.SMPLH('/efs/luomingshuang/codes/ActionPlan-Code/deps/smplh/SMPLH_NEUTRAL.npz',ext='npz',gender='neutral',use_pca=False,flat_hand_mean=True,batch_size=64).cuda().eval().requires_grad_(False);vs=[];js=[];root=savgol_filter(src[:,0],7,2,axis=0,mode='interp')
with torch.no_grad():
 for a in range(0,T,64):
  n=min(64,T-a);body=torch.tensor(rot[a:a+n],device='cuda');hands=torch.eye(3,device='cuda').reshape(1,1,3,3).expand(n,30,3,3);p=torch.cat([body,hands],1);v,j=lbs(torch.zeros(n,10,device='cuda'),p,m.v_template,m.shapedirs,m.posedirs,m.J_regressor,m.parents,m.lbs_weights,pose2rot=False);shift=torch.tensor(root[a:a+n,None],device='cuda')-j[:,:1];vs.append((v+shift).cpu().numpy());js.append((j[:,:22]+shift).cpu().numpy())
j=np.concatenate(js);np.savez_compressed(O/'continuous.npz',vertices=np.concatenate(vs),faces=m.faces,joints=j,rotations=rot)
meta=json.load(open(D/'mesh_ik/continuous.json'));meta.update(anatomical_display_bounds=True,neck_cone_rad=.85,ankle_cone_rad=1.05,neutral_head_wrists_fingers=True,hinge_knees_elbows=True,mean_joint_fit_error_m=float(np.linalg.norm(j-src,axis=-1).mean()),p95_joint_fit_error_m=float(np.percentile(np.linalg.norm(j-src,axis=-1),95)),max_joint_fit_error_m=float(np.linalg.norm(j-src,axis=-1).max()),scope='Display retargeting only. Native motion features, source joints and original timing retained. Not an experimental motion-quality improvement.')
(O/'continuous.json').write_text(json.dumps(meta,indent=2))
