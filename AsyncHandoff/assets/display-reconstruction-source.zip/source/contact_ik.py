from pathlib import Path
import os,sys,json
assert os.environ.get('CUDA_VISIBLE_DEVICES')not in['0','2']
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import numpy as np,torch,smplx
from scipy.spatial.transform import Rotation
from scipy.signal import savgol_filter
from smplx.lbs import lbs
from ik_pose import basis,frame,unit,hinge_angle
D=Path(sys.argv[1]);O=D/'mesh_contact';O.mkdir(exist_ok=True);z=np.load(D/'mesh_anatomical/continuous.npz');rot=z['rotations'].copy();src=np.load(D/'continuous.npz')['joints'];smooth=savgol_filter(src,7,2,axis=0,mode='interp');T=len(rot);root=smooth[:,0];torch.set_num_threads(1)
m=smplx.SMPLH('/efs/luomingshuang/codes/ActionPlan-Code/deps/smplh/SMPLH_NEUTRAL.npz',ext='npz',gender='neutral',use_pca=False,flat_hand_mean=True,batch_size=64).cuda().eval().requires_grad_(False);parents=m.parents.cpu().numpy().astype(int);weights=m.lbs_weights.cpu().numpy();masks=[weights[:,[7,10]].sum(1)>.2,weights[:,[8,11]].sum(1)>.2]
with torch.no_grad():
 rest=m(body_pose=torch.zeros(1,63,device='cuda'),global_orient=torch.zeros(1,3,device='cuda'),betas=torch.zeros(1,10,device='cuda'),left_hand_pose=torch.zeros(1,45,device='cuda'),right_hand_pose=torch.zeros(1,45,device='cuda'),transl=torch.zeros(1,3,device='cuda')).joints[0,:22].cpu().numpy()
def skin():
 vs=[];js=[]
 with torch.no_grad():
  for a in range(0,T,64):
   n=min(64,T-a);pose=torch.cat([torch.tensor(rot[a:a+n],device='cuda'),torch.eye(3,device='cuda').reshape(1,1,3,3).expand(n,30,3,3)],1);v,j=lbs(torch.zeros(n,10,device='cuda'),pose,m.v_template,m.shapedirs,m.posedirs,m.J_regressor,m.parents,m.lbs_weights,pose2rot=False);shift=torch.tensor(root[a:a+n,None],device='cuda')-j[:,:1];vs.append((v+shift).cpu().numpy());js.append((j[:,:22]+shift).cpu().numpy())
 return np.concatenate(vs),np.concatenate(js)
v,j=skin();lift=np.zeros((T,2))
for iteration in range(4):
 G=np.empty_like(rot)
 for q in range(22):G[:,q]=rot[:,q]if q==0 else G[:,parents[q]]@rot[:,q]
 for leg,(hip,knee,ankle)in enumerate([(1,4,7),(2,5,8)]):
  if iteration:lift[:,leg]+=np.maximum(0,.006-v[:,masks[leg],1].min(1))
  L1=np.linalg.norm(rest[knee]-rest[hip]);L2=np.linalg.norm(rest[ankle]-rest[knee]);a0=rest[knee]-rest[hip];b0=rest[ankle]-rest[knee]
  for t in range(T):
   H=j[t,hip];goal=smooth[t,ankle].copy();goal[1]+=lift[t,leg];vv=unit(goal-H);dist=np.clip(np.linalg.norm(goal-H),abs(L1-L2)+1e-5,L1+L2-1e-5);goal=H+dist*vv
   axis=G[t,0,:,0];axis=unit(axis-vv*np.dot(axis,vv));pole=unit(np.cross(vv,axis));co=np.clip((L1*L1+dist*dist-L2*L2)/(2*L1*dist),-1,1);K=H+vv*L1*co+pole*L1*np.sqrt(1-co*co);h=unit(np.cross(K-H,goal-K),axis)
   if np.dot(h,axis)<0:h=-h
   rh=basis(K-H,h)@basis(a0,np.array([1.,0,0])).T;angle=np.clip(hinge_angle(b0,rh.T@(goal-K),np.array([1.,0,0])),0,2.65);rk=rh@Rotation.from_rotvec([angle,0,0]).as_matrix();rot[t,hip]=G[t,parents[hip]].T@rh;rot[t,knee]=Rotation.from_rotvec([angle,0,0]).as_matrix()
   foot=frame(np.array([0.,1,0]),G[t,0,:,0]);local=rk.T@foot;a=Rotation.from_matrix(local).as_rotvec();a=np.clip(a,[-.9,-.35,-.45],[.9,.35,.45]);a*=min(1,1.05/max(np.linalg.norm(a),1e-9));rot[t,ankle]=Rotation.from_rotvec(a).as_matrix()
 v,j=skin()
lo=v[:,:,1].min(1);residual=np.maximum(0,.002-lo);v[:,:,1]+=residual[:,None];j[:,:,1]+=residual[:,None];np.savez_compressed(O/'continuous.npz',vertices=v,faces=m.faces,joints=j,rotations=rot,root_clearance=residual)
meta=json.load(open(D/'mesh_anatomical/continuous.json'));error=np.linalg.norm(j-src,axis=-1);meta.update(no_contact_repair=False,display_only_contact_ik=True,source_contacts_unchanged=True,contact_ik='Source-ankle two-link IK with pelvis-aligned anatomical knee poles, strictly one-axis knees, bounded ankles and floor clearance; no vertex warping',max_residual_root_clearance_m=float(residual.max()),mean_joint_fit_error_m=float(error.mean()),p95_joint_fit_error_m=float(np.percentile(error,95)),max_joint_fit_error_m=float(error.max()),rendered_minimum_y=float(v[:,:,1].min()));(O/'continuous.json').write_text(json.dumps(meta,indent=2));print(json.dumps(meta))
