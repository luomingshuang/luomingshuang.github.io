from pathlib import Path
import sys,os,json
import numpy as np
from PIL import Image,ImageDraw
D=Path(sys.argv[1]).resolve();sys.path.insert(0,str(D));import render_style as r
z=np.load(D/'continuous.npz');m=np.load(D/'mesh_ik/continuous.npz');v=m['vertices'];f=m['faces'];j=z['joints'];R=m['rotations'];out=D/'mesh_ik';meta=json.load(open(D/'complete.json'));commands=[dict(text=c['text'])for c in meta['commands']]
for part,ids in [('full',np.arange(0,len(j),20)),('neck',np.argsort(np.linalg.norm(np.diff(R[:,12],axis=0),axis=(1,2)))[-40:]),('seams',np.concatenate([np.arange(max(0,int(c['target_first_frame'])-5),min(len(j),int(c['target_first_frame'])+8)) for c in meta['commands']])if all('target_first_frame'in c for c in meta['commands'])else np.arange(0,len(j),30))]:
 ids=np.sort(ids);cols=10;rows=int(np.ceil(len(ids)/cols));sheet=Image.new('RGB',(220*cols,240*rows),'white');draw=ImageDraw.Draw(sheet)
 for k,t in enumerate(ids):
  cmd=int(z['command'][t]);im=r.draw_frame(j[t],'target',t,len(j),commands,cmd,'QA',mesh=(v[t],f)).crop((360,170,940,590)).resize((220,220));sheet.paste(im,(k%cols*220,k//cols*240+20));draw.text((k%cols*220,k//cols*240),f'{t} / {t/20:.2f}s',fill='black')
 sheet.save(out/f'qa-{part}.jpg',quality=95)
