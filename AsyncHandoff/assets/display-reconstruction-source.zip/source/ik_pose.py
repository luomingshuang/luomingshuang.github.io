"""Deterministic, twist-resolved SMPL-H visualization IK from recorded 22-joint motion.
Only a display surface is reconstructed; native motion and timestamps are immutable.
"""
import numpy as np
from scipy.spatial.transform import Rotation
PARENTS=[-1,0,0,0,1,2,3,4,5,6,7,8,9,9,9,12,13,14,16,17,18,19]
def unit(x,fallback=None):
 n=np.linalg.norm(x)
 return x/n if n>1e-7 else np.array([0.,1,0])if fallback is None else fallback

def basis(a,h):
 a=unit(a);h=unit(h-a*np.dot(a,h),np.array([1.,0,0]));return np.stack([a,h,unit(np.cross(a,h))],axis=1)
def frame(up,across):
 u=unit(up);x=unit(across-u*np.dot(u,across),np.array([1.,0,0]));return np.stack([x,u,unit(np.cross(x,u))],axis=1)
def swing(a,b):
 a,b=unit(a),unit(b);v=np.cross(a,b);c=np.clip(np.dot(a,b),-1,1);n=np.linalg.norm(v)
 if n<1e-7:
  if c>0:return np.eye(3)
  axis=unit(np.cross(a,[1,0,0])if abs(a[0])<.9 else np.cross(a,[0,0,1]));return Rotation.from_rotvec(np.pi*axis).as_matrix()
 return Rotation.from_rotvec(np.arctan2(n,c)*v/n).as_matrix()
def hinge_angle(rest,target,axis):
 a=unit(rest-axis*np.dot(rest,axis));b=unit(target-axis*np.dot(target,axis));return np.arctan2(np.dot(axis,np.cross(a,b)),np.clip(np.dot(a,b),-1,1))
def poses_from_joints(joints,rest):
 from scipy.signal import savgol_filter
 joints=savgol_filter(joints,7,2,axis=0,mode='interp')
 T=len(joints);G=np.zeros((T,22,3,3));local=np.zeros_like(G);Fpel=frame(rest[3]-rest[0],rest[2]-rest[1]);Fchest=frame(rest[12]-rest[6],rest[17]-rest[16]);I=np.eye(3)
 for t,j in enumerate(joints):
  g=G[t];g[0]=frame(j[3]-j[0],j[2]-j[1])@Fpel.T
  for q,ch in [(3,6),(6,9)]:
   parent=PARENTS[q];g[q]=swing(g[parent]@(rest[ch]-rest[q]),j[ch]-j[q])@g[parent]
  g[9]=frame(j[12]-j[6],j[17]-j[16])@Fchest.T
  g[12]=swing(g[9]@(rest[15]-rest[12]),j[15]-j[12])@g[9];g[15]=g[12]
  for collar,shoulder,elbow,wrist,sign in [(13,16,18,20,-1),(14,17,19,21,1)]:
   g[collar]=swing(g[9]@(rest[shoulder]-rest[collar]),j[shoulder]-j[collar])@g[9]
   a=unit(j[elbow]-j[shoulder]);b=unit(j[wrist]-j[elbow]);h=sign*np.cross(a,b);h0=np.array([0.,1,0]);a0=rest[elbow]-rest[shoulder]
   prior=(G[t-1,shoulder]if t else g[collar])@h0
   if np.linalg.norm(h)<.22:h=prior
   elif np.dot(h,prior)<0:h=-h
   g[shoulder]=basis(a,h)@basis(a0,h0).T
   angle=hinge_angle(rest[wrist]-rest[elbow],g[shoulder].T@b,h0);angle=np.clip(angle,-2.65,.1)if sign<0 else np.clip(angle,-.1,2.65)
   g[elbow]=g[shoulder]@Rotation.from_rotvec(angle*h0).as_matrix();g[wrist]=g[elbow]
  for hip,knee,ankle,toe in [(1,4,7,10),(2,5,8,11)]:
   a=unit(j[knee]-j[hip]);b=unit(j[ankle]-j[knee]);h=np.cross(a,b);h0=np.array([1.,0,0]);a0=rest[knee]-rest[hip]
   prior=(G[t-1,hip]if t else g[0])@h0
   if np.linalg.norm(h)<.22:h=prior
   elif np.dot(h,prior)<0:h=-h
   g[hip]=basis(a,h)@basis(a0,h0).T;angle=np.clip(hinge_angle(rest[ankle]-rest[knee],g[hip].T@b,h0),0,2.7);g[knee]=g[hip]@Rotation.from_rotvec(angle*h0).as_matrix()
   g[ankle]=basis(j[toe]-j[ankle],np.array([0.,1,0]))@basis(rest[toe]-rest[ankle],np.array([0.,1,0])).T;g[toe]=g[ankle]
  for q in range(22):local[t,q]=g[q]if q==0 else g[PARENTS[q]].T@g[q]
 # Resolve high-frequency frame-orientation noise, not source positions.
 for _ in range(2):
  old=G.copy()
  for q in [0,3,6,9,12,7,8,13,14,16,17]:
   r=Rotation.from_matrix(old[:,q]);c=r[1:-1];delta=.2*(c.inv()*r[:-2]).as_rotvec()+.2*(c.inv()*r[2:]).as_rotvec();G[1:-1,q]=(c*Rotation.from_rotvec(delta)).as_matrix()
  # Distal rotations remain neutral relative to their parent, with no twist fit.
  G[:,15]=G[:,12];G[:,20]=G[:,18];G[:,21]=G[:,19];G[:,10]=G[:,7];G[:,11]=G[:,8]
 for q in range(22):local[:,q]=G[:,q]if q==0 else np.swapaxes(G[:,PARENTS[q]],1,2)@G[:,q]
 return local,G
