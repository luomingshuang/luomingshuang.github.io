"""Smooth-shaded SMPL surface only. Does not change joint or vertex positions."""
import numpy as np,moderngl
from PIL import Image
class Surface:
 def __init__(self,width,height,cam):
  self.w=width;self.h=height;self.cam=cam.astype('f4');self.ctx=moderngl.create_standalone_context(backend='egl',device_index=7)
  self.program=self.ctx.program(vertex_shader='''#version 330
in vec3 position; in vec3 normal; uniform mat3 camera; uniform vec3 center; out vec3 n; out vec3 viewn;
void main(){vec3 q=camera*(position-center);gl_Position=vec4(q.x*0.3125,q.y*0.5555556-0.5694444,-q.z/20.0,1.0);n=normal;viewn=camera*normal;}''',fragment_shader='''#version 330
in vec3 n;in vec3 viewn;uniform vec3 color;out vec4 frag;
void main(){vec3 nn=normalize(n);float light=0.46+0.40*max(0.0,dot(nn,normalize(vec3(-0.5,0.8,0.3))))+0.10*max(0.0,dot(nn,normalize(vec3(0.8,0.3,-0.5))));float spec=0.05*pow(max(0.0,normalize(viewn).z),20.0);frag=vec4(color*light+vec3(spec),1.0);}''')
  self.program['camera'].write(self.cam.T.copy().tobytes());self.fb=self.ctx.framebuffer(self.ctx.renderbuffer((width,height),4,samples=4),self.ctx.depth_renderbuffer((width,height),samples=4));self.resolve=self.ctx.simple_framebuffer((width,height),components=4)
 def draw(self,v,f,center,color):
  v=np.asarray(v,'f4');f=np.asarray(f,'i4');tri=v[f];fn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);norm=np.zeros_like(v)
  for corner in range(3):
   for axis in range(3):norm[:,axis]+=np.bincount(f[:,corner],weights=fn[:,axis],minlength=len(v))
  norm/=np.maximum(np.linalg.norm(norm,axis=1,keepdims=True),1e-12);data=np.concatenate([v,norm],axis=1).astype('f4');vb=self.ctx.buffer(data.tobytes());ib=self.ctx.buffer(f.tobytes());vao=self.ctx.vertex_array(self.program,[(vb,'3f 3f','position','normal')],index_buffer=ib)
  self.program['center'].value=tuple(map(float,center));self.program['color'].value=tuple(map(float,color/255));self.fb.use();self.fb.clear(0,0,0,0,depth=1);self.ctx.enable(moderngl.DEPTH_TEST);vao.render(moderngl.TRIANGLES);self.ctx.copy_framebuffer(self.resolve,self.fb);im=Image.frombytes('RGBA',(self.w,self.h),self.resolve.read(components=4,alignment=1)).transpose(Image.Transpose.FLIP_TOP_BOTTOM);vao.release();vb.release();ib.release();return im
