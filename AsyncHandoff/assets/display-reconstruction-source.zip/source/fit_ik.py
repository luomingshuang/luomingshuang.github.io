from pathlib import Path
import os,sys,json,time
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import numpy as np,torch,smplx
from smplx.lbs import lbs
from ik_pose import poses_from_joints
D=Path(sys.argv[1]).resolve();OUT=D/'mesh_ik';OUT.mkdir(exist_ok=True);torch.set_num_threads(1);target=np.load(D/'continuous.npz')['joints'];T=len(target)
m=smplx.SMPLH('/efs/luomingshuang/codes/ActionPlan-Code/deps/smplh/SMPLH_NEUTRAL.npz',ext='npz',gender='neutral',use_pca=False,flat_hand_mean=True,batch_size=64).cuda().eval().requires_grad_(False)
with torch.no_grad():
 zero=torch.zeros(1,63,device='cuda');out=m(body_pose=zero,global_orient=torch.zeros(1,3,device='cuda'),betas=torch.zeros(1,10,device='cuda'),left_hand_pose=torch.zeros(1,45,device='cuda'),right_hand_pose=torch.zeros(1,45,device='cuda'),transl=torch.zeros(1,3,device='cuda'));rest=out.joints[0,:22].cpu().numpy()
local,global_ref=poses_from_joints(target,rest);ref=torch.tensor(local,dtype=torch.float32,device='cuda');vertices=[];fits=[];allposes=[]
# Small bounded corrections only; torso/head frames are fixed by anatomical IK.
trainable=[1,2,4,5,16,17,18,19];parents=list(map(int,m.parents.cpu().tolist()))
def build_pose(lref,delta):
 from smplx.lbs import batch_rodrigues
 n=len(lref);Rs=[];Gs=[];lookup={j:k for k,j in enumerate(trainable)}
 for j in range(22):
  R=lref[:,j]
  if j in lookup:R=R@batch_rodrigues(.12*torch.tanh(delta[:,lookup[j]])).reshape(n,3,3)
  if j in [7,8]:
   # Keep global foot orientation anchored; prevent hidden ankle axial twist.
   desired=torch.tensor(global_ref[first:first+n,j],dtype=torch.float32,device='cuda');R=Gs[parents[j]].transpose(1,2)@desired
  G=R if j==0 else Gs[parents[j]]@R;Rs.append(R);Gs.append(G)
 hands=torch.eye(3,device='cuda').reshape(1,1,3,3).expand(n,30,3,3);return torch.cat([torch.stack(Rs,1),hands],1)
for first in range(0,T,64):
 y=torch.tensor(target[first:first+64],device='cuda');lref=ref[first:first+64];n=len(y);d=torch.nn.Parameter(torch.zeros(n,len(trainable),3,device='cuda'));opt=torch.optim.Adam([d],lr=.035)
 for _ in range(80):
  opt.zero_grad();pose=build_pose(lref,d);v,j=lbs(torch.zeros(n,10,device='cuda'),pose,m.v_template,m.shapedirs,m.posedirs,m.J_regressor,m.parents,m.lbs_weights,pose2rot=False);shift=y[:,:1]-j[:,:1];loss=((j[:,:22]+shift-y)**2).mean()+.002*(.12*torch.tanh(d)).square().mean();loss.backward();opt.step()
 with torch.no_grad():
  pose=build_pose(lref,d);v,j=lbs(torch.zeros(n,10,device='cuda'),pose,m.v_template,m.shapedirs,m.posedirs,m.J_regressor,m.parents,m.lbs_weights,pose2rot=False);shift=y[:,:1]-j[:,:1];vertices.append((v+shift).cpu().numpy());fits.append((j[:,:22]+shift).cpu().numpy());allposes.append(pose[:,:22].cpu().numpy())
 (D/'ik_progress.json').write_text(json.dumps(dict(frame=first,total=T)))
# Display-only SO(3) temporal filtering: skinning is rerun from rotations, never
# averaged vertices, so the body retains a fixed shape and valid bone lengths.
from scipy.spatial.transform import Rotation
from scipy.signal import savgol_filter
rot=np.concatenate(allposes)
weights=np.array([.05,.10,.20,.30,.20,.10,.05])
for _ in range(2):
 old=rot.copy()
 for q in range(22):
  rr=Rotation.from_matrix(old[:,q]);base=rr.as_matrix();delta=np.zeros((T,3))
  for off,w in zip(range(-3,4),weights):
   ix=np.clip(np.arange(T)+off,0,T-1);delta+=w*(rr.inv()*rr[ix]).as_rotvec()
  rot[:,q]=(rr*Rotation.from_rotvec(delta)).as_matrix()
# Native joint positions/features remain untouched; only this display root is filtered.
display_root=savgol_filter(target[:,0],7,2,axis=0,mode='interp');vertices=[];fits=[]
with torch.no_grad():
 for first in range(0,T,64):
  n=min(64,T-first);body=torch.tensor(rot[first:first+n],device='cuda');hands=torch.eye(3,device='cuda').reshape(1,1,3,3).expand(n,30,3,3);pose=torch.cat([body,hands],1)
  v,j=lbs(torch.zeros(n,10,device='cuda'),pose,m.v_template,m.shapedirs,m.posedirs,m.J_regressor,m.parents,m.lbs_weights,pose2rot=False)
  shift=torch.tensor(display_root[first:first+n,None],device='cuda')-j[:,:1];vertices.append((v+shift).cpu().numpy());fits.append((j[:,:22]+shift).cpu().numpy())
fit=np.concatenate(fits);error=np.linalg.norm(fit-target,axis=-1);np.savez_compressed(OUT/'continuous.npz',vertices=np.concatenate(vertices),faces=m.faces,joints=fit,rotations=rot,reference_global=global_ref)
receipt=dict(frames=T,fixed_neutral_shape=True,source_motion_unchanged=True,method='Twist-resolved skeletal IK; anatomical torso, neck and foot frames; neutral distal hands/head; bounded limb fitting; SO(3) display filtering followed by fresh skinning',max_limb_correction_rad=.12,rotation_prior_weight=.002,mean_joint_fit_error_m=float(error.mean()),p95_joint_fit_error_m=float(np.percentile(error,95)),max_joint_fit_error_m=float(error.max()),body_frames_temporally_regularized=True,display_position_filter=dict(window=7,order=2),display_rotation_filter=dict(weights=weights.tolist(),passes=2),no_contact_repair=True)
(OUT/'continuous.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
