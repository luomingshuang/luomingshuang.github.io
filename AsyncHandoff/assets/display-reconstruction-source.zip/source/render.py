from pathlib import Path
import sys,os,json,shutil,hashlib,subprocess
import numpy as np
from PIL import Image,ImageDraw
from scipy.spatial.transform import Rotation
D=Path(sys.argv[1]).resolve();backend=sys.argv[2];caseid=int(sys.argv[3]);gpu=int(sys.argv[4]);assert gpu not in [0,2], 'GPU 0/2 reserved by user';B=Path('/efs/luomingshuang/codes/flooddiffusion_lmr_planner_actor');R=B/'research_v355_fifteen_provider_minutes';S=D/'display_ik';S.mkdir(exist_ok=True)
import fcntl
render_lock=(S/'render.lock').open('a');fcntl.flock(render_lock,fcntl.LOCK_EX)
if (S/'receipt.json').exists():
 prior=json.load(open(S/'receipt.json'))
 if prior.get('renderer_version')==5 and (S/'media'/prior['video']).exists() and hashlib.sha256((S/'media'/prior['video']).read_bytes()).hexdigest()==prior['sha256']:print('Already completed latest rendering');sys.exit(0)
for name in ['render_style.py','gpu_surface.py']:shutil.copy2(B/'research_v353_chinese_complex_demo'/name,S/name)
p=S/'gpu_surface.py';p.write_text(p.read_text().replace('device_index=7',f'device_index={gpu}'))
p=S/'render_style.py';s=p.read_text();a=s.index(' text=');b=s.index('\n # Wrap caption',a);s=s[:a]+" text='Instruction: '+commands[cmd]['text'] if cmd>=0 else 'Streaming motion before target playback'"+s[b:];s=s.replace('SMPL-H · temporally regularized visualization · source motion and timestamps unchanged','SMPL-H · smoothed display reconstruction · raw motion and timestamps retained');s=s.replace("font=fonts[30],fill='#ffffff'","font=fonts[24],fill='#ffffff'")
s=s.replace("for k,line in enumerate(lines[:2]):d.text((48,606+k*25),line,font=fonts[20],fill='#eef3f7')", "for k,line in enumerate(lines[:2]):d.text((48,627+k*22),line,font=fonts[18],fill='#eef3f7')")
s=s.replace(" # Wrap caption into at most two lines", " if cmd>=0 and 'text_zh'in commands[cmd]:d.text((48,588),commands[cmd]['text_zh'],font=ImageFont.truetype('/efs/luomingshuang/codes/flooddiffusion_lmr_planner_actor/research_v355_fifteen_provider_minutes/renderer/fonts/NotoSansCJKsc-Regular.otf',22),fill='#eef3f7')\n # Wrap caption into at most two lines")
s=s.replace("font=fonts[20])>1120","font=fonts[18])>1120")
p.write_text(s)
sys.path.insert(0,str(S));import render_style as r

if not (D/'mesh_anatomical/continuous.json').exists():subprocess.run(['/usr/local/bin/python',str(R/'renderer/anatomical.py'),str(D)],check=True)
if not (D/'mesh_ground/continuous.json').exists():subprocess.run(['/usr/local/bin/python',str(R/'renderer/ground_ik.py'),str(D)],check=True)
z=np.load(D/'continuous.npz');mesh=np.load(D/'mesh_ground/continuous.npz');v=mesh['vertices'];faces=mesh['faces'];j=mesh['joints'];
ground_dy=mesh['root_clearance'];
m=json.load(open(D/'complete.json'));clock=np.arange(1200)/20;ix=np.maximum(0,np.searchsorted(z['clock'],clock,side='right')-1);o=z['source_ownership'][ix];kind=z['kind'][ix];cmd=z['command'][ix];ph=np.array(['target'if x>=0 else'bridge'if k=='committed'else'continuation'if k=='continuation'else'hold'if'hold'in k else'response'for x,k in zip(o,kind)])
assert m['all_targets_full'] and m['unserved_s']<.051
assert len(m['commands'])==len(json.load(open(D/'registration.json'))['texts']), 'Not all registered instructions were executed'
for c in m['commands']:
 N=c['displayed_target_frames'];own=np.where((o>=c['index']*100000)&(o<c['index']*100000+N))[0];assert np.array_equal(o[own][np.r_[True,np.diff(o[own])!=0]],np.arange(N)+c['index']*100000) and c['native_target_exact']
 before=(cmd==c['index'])&(o<0)&(ix<ix[own[0]])&(ph!='bridge');ph[before]='response';ph[(cmd==c['index'])&(o<0)&(ix>ix[own[-1]])]='continuation'
commands=[dict(text=c['text'],text_zh=c['text_zh'],start_frame=int(np.ceil(c['issued_s']*20)))for c in m['commands']];label={'salad':'SALAD','motionhiflow':'MotionHiFlow','motiongpt3':'MotionGPT3'}[backend];name=f'{backend}-minute-{caseid:02d}.mp4';dest=r.OUT/name
proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{r.W}x{r.H}','-r','20','-i','-','-an','-c:v','libx264','-threads','2','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(dest)],stdin=subprocess.PIPE)
for t,q in enumerate(ix):
 im=r.draw_frame(j[q],str(ph[t]),t,len(ix),commands,int(cmd[t]),f'{label} · {len(commands)} successive instructions',mesh=(v[q],faces));proc.stdin.write(im.tobytes())
 if t==100:im.save(r.OUT/f'{backend}-minute-{caseid:02d}-poster.webp',quality=95)
 if t%100==0:(S/'progress.json').write_text(json.dumps(dict(frame=t,total=1200)))
proc.stdin.close();assert proc.wait()==0
# One frame per half second, plus dense entry/return seams and worst rotations.
rot=mesh['rotations'];angles={};worst=[]
for part,ids in {'neck':[12,15],'hips':[1,2],'knees':[4,5],'elbows':[18,19],'wrists':[20,21],'ankles':[7,8]}.items():
 ds=np.stack([np.rad2deg((Rotation.from_matrix(rot[:-1,q]).inv()*Rotation.from_matrix(rot[1:,q])).magnitude())for q in ids],1);angles[part]=dict(p95_frame_deg=float(np.percentile(ds,95)),max_frame_deg=float(ds.max()));worst.extend(np.argsort(ds.max(1))[-8:].tolist())
for mode in ['overview','entry','return','worst']:
 frames=[]
 if mode=='overview':frames=np.arange(0,len(j),10)
 elif mode=='worst':frames=np.unique(worst)
 else:
  for c in m['commands']:
   own=np.where((z['source_ownership']>=c['index']*100000)&(z['source_ownership']<c['index']*100000+c['displayed_target_frames']))[0];center=own[0]if mode=='entry'else own[-1]+1;frames.extend(np.clip(center+np.arange(-6,7),0,len(j)-1).tolist())
 cols=10;rows=int(np.ceil(len(frames)/cols));sheet=Image.new('RGB',(220*cols,240*rows),'white');draw=ImageDraw.Draw(sheet)
 for k,t in enumerate(frames):
  im=r.draw_frame(j[t],'target',int(t),len(j),commands,int(z['command'][t]),'QA',mesh=(v[t],faces)).crop((360,170,940,590)).resize((220,220));sheet.paste(im,(k%cols*220,k//cols*240+20));draw.text((k%cols*220,k//cols*240),f'{t} / {float(z["clock"][t]):.2f}s',fill='black')
 sheet.save(r.OUT/f'qa-{mode}.jpg',quality=95)
receipt=dict(renderer_version=5,display_ground_alignment=dict(method='Two-bone leg IK for floor clearance; pelvis trajectory retained; bounded ankles; residual uniform clearance only; no vertex warping',max_absolute_adjustment_m=float(abs(ground_dy).max()),p95_frame_adjustment_step_m=float(np.percentile(abs(np.diff(ground_dy)),95)),max_frame_adjustment_step_m=float(abs(np.diff(ground_dy)).max()),rendered_minimum_surface_y_m=float(v[:,:,1].min()),joint_mean_error_after_retarget_m=float(np.linalg.norm(j-z['joints'],axis=-1).mean())),provider=label,case=caseid,video=name,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),duration_s=60,frames=1200,fps=20,source_directory=str(D.relative_to(B)),commands=m['commands'],all_targets_full=m['all_targets_full'],unserved_s=m['unserved_s'],native_targets_unchanged=True,rotation_audit=angles,surface=json.load(open(D/'mesh_ground/continuous.json')),configuration=json.load(open(D/'registration.json')),scope=f'Selected qualitative demonstration. {len(commands)} complete targets on one continuous player. Display-only position/rotation smoothing, anatomical reconstruction and floor retargeting; raw native features, ownership and actual timing retained. No within-action cuts, speedup, or benchmark updates.',language='Chinese authored instructions with actual English model-input translations; not a native Chinese-language benchmark',visual_review='pending')
(S/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2));print('Rendered',dest,flush=True)
