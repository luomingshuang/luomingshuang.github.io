"""Joint-driven surface rendering; source poses/timing are not smoothed or repaired."""
from pathlib import Path
import numpy as np,json,subprocess,hashlib,time
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parent;OUT=R/'media';OUT.mkdir(parents=True,exist_ok=True)
W,H=1280,720
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
fonts={k:ImageFont.truetype(BOLD if k in [24,30,40]else FONT,k)for k in [14,16,18,20,24,30,40]}
yaw=np.deg2rad(-58);el=np.deg2rad(13);c,s=np.cos(yaw),np.sin(yaw);ce,se=np.cos(el),np.sin(el);CAM=np.array([[c,0,s],[se*s,ce,-se*c],[-ce*s,se,ce*c]])
LIGHT=np.array([-.5,.8,.3]);LIGHT/=np.linalg.norm(LIGHT)
COLORS={'response':'#78a9d3','bridge':'#ba91d3','target':'#ecb76b','continuation':'#a7c69a'}

def unit(v):return v/max(np.linalg.norm(v),1e-9)
def rings_mesh(rings):
 v=np.concatenate(rings);n=len(rings[0]);f=[]
 for a in range(len(rings)-1):
  for q in range(n):
   i=a*n+q;j=a*n+(q+1)%n;f.extend([(i,j,i+n),(j,j+n,i+n)])
 return v,np.array(f)
def tube(a,b,r1,r2,n=10):
 d=unit(b-a);u=unit(np.cross(d,np.array([0,1.,0])if abs(d[1])<.9 else np.array([1.,0,0])));v=np.cross(d,u);t=np.arange(n)*2*np.pi/n
 rings=[a+r1*(np.cos(t)[:,None]*u+np.sin(t)[:,None]*v),b+r2*(np.cos(t)[:,None]*u+np.sin(t)[:,None]*v)]
 return rings_mesh(rings)
def ellipsoid(center,radii,axes=np.eye(3),n=10,m=7):
 rings=[]
 for ph in np.linspace(.025,np.pi-.025,m):
  th=np.arange(n)*2*np.pi/n;local=np.stack([np.sin(ph)*np.cos(th)*radii[0],np.full(n,np.cos(ph)*radii[1]),np.sin(ph)*np.sin(th)*radii[2]],1);rings.append(center+local@axes.T)
 return rings_mesh(rings)
def body_mesh(j):
 parts=[];up=unit(j[12]-j[0]);right=unit(j[17]-j[16]);forward=unit(np.cross(right,up));right=unit(np.cross(up,forward));axes=np.stack([right,up,forward],1)
 # Soft torso, limbs, hands, feet and head, driven directly by the 22 recorded joints.
 rings=[];angles=np.arange(14)*2*np.pi/14
 for idx,ww,dd in [(0,.13,.085),(3,.125,.085),(6,.14,.09),(9,.18,.095),(12,.062,.05)]:
  rings.append(j[idx]+np.cos(angles)[:,None]*right*ww+np.sin(angles)[:,None]*forward*dd)
 parts.append(rings_mesh(rings))
 for a,b,r1,r2 in [(0,1,.08,.075),(1,4,.075,.055),(4,7,.052,.037),(0,2,.08,.075),(2,5,.075,.055),(5,8,.052,.037),(9,16,.055,.055),(16,18,.05,.036),(18,20,.036,.026),(9,17,.055,.055),(17,19,.05,.036),(19,21,.036,.026),(12,15,.043,.043)]:
  parts.append(tube(j[a],j[b],r1,r2));parts.append(ellipsoid(j[b],(r2,r2,r2),n=8,m=5))
 parts.append(ellipsoid(j[15]+up*.055,(.084,.118,.086),axes,n=14,m=9))
 for wrist,elbow in [(20,18),(21,19)]:parts.append(ellipsoid(j[wrist]+unit(j[wrist]-j[elbow])*.035,(.034,.055,.022),axes,n=8,m=6))
 for ankle,toe in [(7,10),(8,11)]:
  center=.45*j[ankle]+.55*j[toe];parts.append(ellipsoid(center,(.044,.035,max(.08,np.linalg.norm(j[toe]-j[ankle])*.62)),axes,n=10,m=6))
 verts=[];faces=[];offset=0
 for v,f in parts:verts.append(v);faces.append(f+offset);offset+=len(v)
 return np.concatenate(verts),np.concatenate(faces)
def rgb(h):return np.array([int(h[i:i+2],16)for i in [1,3,5]],float)
def project(v,center):
 q=(v-center)@CAM.T;return np.stack([640+q[:,0]*200,565-q[:,1]*200],1),q[:,2]
def draw_frame(j,phase,frame,total,commands,cmd,mode,mesh=None):
 bg=np.empty((H,W,3),np.uint8)
 for y in range(H):bg[y]=np.array([11,23,35])*(1-y/H)+np.array([27,43,57])*(y/H)
 im=Image.fromarray(bg);d=ImageDraw.Draw(im);center=np.array([j[0,0],0,j[0,2]])
 for x in range(int(center[0])-5,int(center[0])+6):
  a=np.array([[x,0,center[2]-5],[x,0,center[2]+5]]);p,_=project(a,center);d.line([tuple(q)for q in p],fill=(44,60,74),width=1)
 for z in range(int(center[2])-5,int(center[2])+6):
  a=np.array([[center[0]-5,0,z],[center[0]+5,0,z]]);p,_=project(a,center);d.line([tuple(q)for q in p],fill=(44,60,74),width=1)
 shadow=Image.new('RGBA',(W,H));sd=ImageDraw.Draw(shadow);p,_=project(np.array([[j[0,0],0,j[0,2]]]),center);x,y=p[0]
 for r in range(32,3,-2):sd.ellipse((x-2.5*r,y-.4*r,x+2.5*r,y+.4*r),fill=(0,0,0,2))
 im=Image.alpha_composite(im.convert('RGBA'),shadow).convert('RGB');d=ImageDraw.Draw(im)
 v,f=body_mesh(j) if mesh is None else mesh
 im=Image.alpha_composite(im.convert('RGBA'),SURFACE.draw(v,f,center,rgb(COLORS.get(phase,COLORS['response'])))).convert('RGB');d=ImageDraw.Draw(im)
 # Editorial layer is separate from the pose renderer.
 d.text((48,32),'ASYNCHANDOFF',font=fonts[18],fill='#eaf0f6');d.text((48,65),'Complete actions. Continuous motion.',font=fonts[30],fill='#ffffff')
 lab={'response':'STREAMING RESPONSE','bridge':'LEARNED ENTRY','target':'COMPLETE TARGET','continuation':'HISTORY CONTINUATION'}.get(phase,'RECORDED HOLD')
 color=COLORS.get(phase,'#bcc6d2');d.rounded_rectangle((970,35,1230,74),radius=18,fill='#1c2e40',outline=color,width=1);d.text((990,46),lab,font=fonts[14],fill=color)
 secs=frame/20;d.text((48,120),mode,font=fonts[16],fill='#a6b7c7');d.text((1130,120),f'{secs:05.1f} s',font=fonts[16],fill='#a6b7c7')
 text=('History continuation after: ' if phase=='continuation' else 'Requested action: ')+commands[cmd]['text'] if cmd>=0 else 'Streaming motion before target playback'
 # Wrap caption into at most two lines, preserving original words.
 words=text.split();lines=['']
 for word in words:
  if d.textlength(lines[-1]+' '+word,font=fonts[20])>1120:lines.append(word)
  else:lines[-1]=(lines[-1]+' '+word).strip()
 for k,line in enumerate(lines[:2]):d.text((48,606+k*25),line,font=fonts[20],fill='#eef3f7')
 y=680;d.rounded_rectangle((48,y,1230,y+4),radius=2,fill='#35485a');d.rounded_rectangle((48,y,48+max(1,1182*frame/total),y+4),radius=2,fill=color)
 for row in commands:
  x=48+1182*row.get('start_frame',0)/total;d.line((x,y-5,x,y+9),fill='#8d9ead',width=1)
 d.text((48,696),('SMPL-H · temporally regularized visualization · source motion and timestamps unchanged' if mesh is not None else 'Joint-driven surface · root-follow camera · no pose smoothing'),font=fonts[14],fill='#91a5b6')
 return im

from gpu_surface import Surface
SURFACE=Surface(W,H,CAM)

def render(data,meta,name,raw=False):
 dest=OUT/(name+'.mp4');j=data['joints'];total=len(j)
 if raw:
  own=data['source_ownership'];kind=data['kind'];phases=np.array(['target'if n>=0 else 'continuation'if str(k)in ['FD_continuation','FD_outlet']else'response'for n,k in zip(own,kind)]);cmds=np.zeros(total,dtype=int);commands=[dict(text=meta['query']['text'],start_frame=0)]
 else:phases=data['phase'];cmds=data['command'];commands=meta['commands']
 proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','20','-i','-','-an','-c:v','libx264','-threads','3','-preset','fast','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(dest)],stdin=subprocess.PIPE)
 for t,pose in enumerate(j):
  image=draw_frame(pose,str(phases[t]),t,total,commands,int(cmds[t]),'Recorded wall-grid playback · original timing'if raw else('Fresh inference · four successive instructions · original 20 Hz playback' if name.startswith('live-') else 'Offline native replay · cached targets and history continuations'),mesh=(data['vertices'][t],data['faces']) if 'vertices' in data else None)
  if t==int(total*.35):image.save(OUT/(name+'-poster.webp'),quality=93)
  if not raw and str(phases[t])=='target'and int(cmds[t])==1 and t%5==0 and pose[0,1]>1.1:image.save(OUT/'hero-poster.webp',quality=95)
  proc.stdin.write(image.tobytes())
  if t%100==0:(R/'render_progress.json').write_text(json.dumps(dict(video=name,frame=t,total=total)))
 proc.stdin.close();assert proc.wait()==0
 return dict(file=dest.name,frames=total,fps=20,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),renderer='joint-driven surface, no pose smoothing, no contact correction',raw_timing=raw)
if __name__=='__main__':
 m=json.loads((R/'four_command_native_replay.json').read_text());z=np.load(R/'four_command_native_replay.npz');rows=[render(z,m,'four-command-replay')]
 p=R/'raw/q00005.npz';rows.append(render(np.load(p),json.loads(p.with_suffix('.json').read_text()),'recorded-history-playback',True));(R/'render_receipts.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
